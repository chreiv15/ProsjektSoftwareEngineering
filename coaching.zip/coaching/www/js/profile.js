console.log('hello!');

readLogin();
$("#user-email").val(login.email);
