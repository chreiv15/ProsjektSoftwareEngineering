<?php

require_once 'user.php';
require_once '../functions.php';

echo getAccounts($userId);

?>