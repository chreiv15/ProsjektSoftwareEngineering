<head>
<meta charset="utf-8">
<style>
    p {
        font-family: sans-serif;
    }
    input, img {
        display: block;
        margin-bottom: 10px;
    }
    input {
        padding: 5px;
    }
    .box img {
        width: 300px; 
    }
</style>
<script></script>
</head>

<form>
    <div class="box">
        <img src="images/rema1000.jpg">
        <p>Dagligvarer</p>
        <input name="price" id="price" value="500">
        <input name="name" id="name" value="Dagligvarer">
        <input name="category" id="category" value="1">
        <input type="submit" value="Kjøp">
    </div>
</form>