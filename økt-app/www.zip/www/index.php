<?php

    require_once 'header.php';
    echo '<p>Hello world!</p>';

?>